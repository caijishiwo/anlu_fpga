/**
 * @file lv_anim_timeline.c
 *
 */

/*********************
 *      INCLUDES
 *********************/

#include "lv_anim_private.h"
#include "lv_anim_timeline_private.h"

/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/
static void anim_timeline_exec_cb(void * var, int32_t v);
static void anim_timeline_set_act_time(lv_anim_timeline_t * at, uint32_t act_time);
static int32_t anim_timeline_path_cb(const lv_anim_t * a);
static void exec_anim(lv_anim_t * a, int32_t v);

/**********************
 *  STATIC VARIABLES
 **********************/

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

lv_anim_timeline_t * lv_anim_timeline_create(void)
{
    lv_anim_timeline_t * at = lv_malloc_zeroed(sizeof(lv_anim_timeline_t));
    LV_ASSERT_MALLOC(at);
    return at;
}

void lv_anim_timeline_delete(lv_anim_timeline_t * at)
{
    if(at == NULL) return;

    lv_anim_timeline_pause(at);

    lv_free(at->anim_dsc);
    lv_free(at);
}

void lv_anim_timeline_add(lv_anim_timeline_t * at, uint32_t start_time, const lv_anim_t * a)
{
    LV_CHECK_ARG(at != NULL, return);
    LV_CHECK_ARG(a != NULL, return);

    at->anim_dsc_cnt++;
    at->anim_dsc = lv_realloc(at->anim_dsc, at->anim_dsc_cnt * sizeof(lv_anim_timeline_dsc_t));

    LV_ASSERT_MALLOC(at->anim_dsc);

    at->anim_dsc[at->anim_dsc_cnt - 1].anim = *a;
    at->anim_dsc[at->anim_dsc_cnt - 1].start_time = start_time;
}


uint32_t lv_anim_timeline_start(lv_anim_timeline_t * at)
{
    LV_CHECK_ARG(at != NULL, return 0);

    uint32_t playtime = lv_anim_timeline_get_playtime(at);

    if((!at->reverse && at->act_time == 0) || (at->reverse && at->act_time == playtime)) {
        for(uint32_t i = 0; i < at->anim_dsc_cnt; i++) {
            at->anim_dsc[i].is_started   = 0;
            at->anim_dsc[i].is_completed = 0;
        }
    }

    /*Always animate the whole 0..playtime range in `playtime` ms and seek into it if
     *the timeline is not at its beginning. Starting the animation at `act_time`
     *instead would shorten it, and as a repeat replays the same values, every later
     *repeat would keep playing only that remaining part.*/
    lv_anim_t a;
    lv_anim_init(&a);
    lv_anim_set_var(&a, at);
    lv_anim_set_exec_cb(&a, anim_timeline_exec_cb);
    if(at->reverse) lv_anim_set_values(&a, playtime, 0);
    else lv_anim_set_values(&a, 0, playtime);

    lv_anim_set_duration(&a, playtime);
    lv_anim_set_path_cb(&a, anim_timeline_path_cb);
    lv_anim_set_repeat_count(&a, at->repeat_count);
    lv_anim_set_repeat_delay(&a, at->repeat_delay);

    /*How much of the timeline has already played. A reversed one counts from its end.*/
    uint32_t elapsed = at->reverse ? playtime - at->act_time : at->act_time;
    if(elapsed == 0) {
        /*Apply the delay only if playing from any ends*/
        lv_anim_set_delay(&a, at->delay);
    }
    else {
        /*`lv_anim_set_delay()` writes act_time as well, so seek after it*/
        a.act_time = (int32_t)elapsed;
    }

    lv_anim_start(&a);

    return playtime;
}

uint32_t lv_anim_timeline_restart(lv_anim_timeline_t * at)
{
    LV_CHECK_ARG(at != NULL, return 0);

    lv_anim_timeline_set_progress(at, at->reverse ? LV_ANIM_TIMELINE_PROGRESS_MAX : 0);
    return lv_anim_timeline_start(at);
}

void lv_anim_timeline_pause(lv_anim_timeline_t * at)
{
    LV_CHECK_ARG(at != NULL, return);

    lv_anim_delete(at, anim_timeline_exec_cb);
}

void lv_anim_timeline_set_reverse(lv_anim_timeline_t * at, bool reverse)
{
    LV_CHECK_ARG(at != NULL, return);
    at->reverse = reverse;
}

void lv_anim_timeline_set_delay(lv_anim_timeline_t * at, uint32_t delay)
{
    LV_CHECK_ARG(at != NULL, return);
    at->delay = delay;
}

void lv_anim_timeline_set_repeat_count(lv_anim_timeline_t * at, uint32_t cnt)
{
    LV_CHECK_ARG(at != NULL, return);
    at->repeat_count = cnt;
}

void lv_anim_timeline_set_repeat_delay(lv_anim_timeline_t * at, uint32_t delay)
{
    LV_CHECK_ARG(at != NULL, return);
    at->repeat_delay = delay;
}

void lv_anim_timeline_set_progress(lv_anim_timeline_t * at, uint16_t progress)
{
    LV_CHECK_ARG(at != NULL, return);

    uint32_t playtime = lv_anim_timeline_get_playtime(at);
    uint32_t act_time = lv_map(progress, 0, LV_ANIM_TIMELINE_PROGRESS_MAX, 0, playtime);
    anim_timeline_set_act_time(at, act_time);
}

void lv_anim_timeline_set_user_data(lv_anim_timeline_t * at, void * user_data)
{
    LV_CHECK_ARG(at != NULL, return);
    at->user_data = user_data;
}

uint32_t lv_anim_timeline_get_playtime(lv_anim_timeline_t * at)
{
    LV_CHECK_ARG(at != NULL, return 0);

    uint32_t playtime = 0;
    for(uint32_t i = 0; i < at->anim_dsc_cnt; i++) {
        uint32_t end = lv_anim_get_playtime(&at->anim_dsc[i].anim);
        if(end == LV_ANIM_PLAYTIME_INFINITE)
            return end;
        end += at->anim_dsc[i].start_time;
        if(end > playtime) {
            playtime = end;
        }
    }

    return playtime;
}

bool lv_anim_timeline_get_reverse(lv_anim_timeline_t * at)
{
    LV_CHECK_ARG(at != NULL, return false);
    return at->reverse;
}


uint32_t lv_anim_timeline_get_delay(lv_anim_timeline_t * at)
{
    LV_CHECK_ARG(at != NULL, return 0);
    return at->delay;
}

uint16_t lv_anim_timeline_get_progress(lv_anim_timeline_t * at)
{
    LV_CHECK_ARG(at != NULL, return 0);
    uint32_t playtime = lv_anim_timeline_get_playtime(at);
    return lv_map(at->act_time, 0, playtime, 0, LV_ANIM_TIMELINE_PROGRESS_MAX);
}

uint32_t lv_anim_timeline_get_repeat_count(lv_anim_timeline_t * at)
{
    LV_CHECK_ARG(at != NULL, return 0);
    return  at->repeat_count;
}

uint32_t lv_anim_timeline_get_repeat_delay(lv_anim_timeline_t * at)
{
    LV_CHECK_ARG(at != NULL, return 0);
    return  at->repeat_delay;
}

void * lv_anim_timeline_get_user_data(lv_anim_timeline_t * at)
{
    LV_CHECK_ARG(at != NULL, return NULL);
    return at->user_data;
}

void lv_anim_timeline_merge(lv_anim_timeline_t * dest, const lv_anim_timeline_t * src, int32_t delay)
{
    LV_CHECK_ARG(dest != NULL, return);
    LV_CHECK_ARG(src != NULL, return);
    uint32_t i;
    for(i = 0; i < src->anim_dsc_cnt; i++) {
        uint32_t anim_delay = src->anim_dsc[i].start_time + delay;
        lv_anim_timeline_add(dest, anim_delay, &src->anim_dsc[i].anim);
    }
}


/**********************
 *   STATIC FUNCTIONS
 **********************/

static void anim_timeline_set_act_time(lv_anim_timeline_t * at, uint32_t act_time)
{
    at->act_time = act_time;
    bool anim_timeline_is_started = (lv_anim_get(at, anim_timeline_exec_cb) != NULL);
    for(uint32_t i = 0; i < at->anim_dsc_cnt; i++) {
        lv_anim_timeline_dsc_t * anim_dsc = &(at->anim_dsc[i]);
        lv_anim_t * a = &(anim_dsc->anim);

        uint32_t start_time = anim_dsc->start_time;
        int32_t value = 0;

        if(act_time < start_time && a->early_apply) {
            if(anim_timeline_is_started) {
                if(at->reverse) {
                    if(!anim_dsc->is_started && a->start_cb)  a->start_cb(a);
                    anim_dsc->is_started = 1;
                }
                else {
                    anim_dsc->is_started = 0;
                }
            }

            value = a->start_value;
            exec_anim(a, value);

            if(anim_timeline_is_started) {
                if(at->reverse) {
                    if(!anim_dsc->is_completed && a->completed_cb) a->completed_cb(a);
                    anim_dsc->is_completed = 1;
                }
                else {
                    anim_dsc->is_completed = 0;
                }
            }
        }
        else if(act_time >= start_time && act_time <= (start_time + a->duration)) {
            if(anim_timeline_is_started) {
                if(!anim_dsc->is_started && a->start_cb) a->start_cb(a);
                anim_dsc->is_started = 1;
            }

            a->act_time = act_time - start_time;
            value = a->path_cb(a);
            exec_anim(a, value);

            if(anim_timeline_is_started) {
                if(at->reverse) {
                    if(act_time == start_time) {
                        if(!anim_dsc->is_completed && a->completed_cb) a->completed_cb(a);
                        anim_dsc->is_completed = 1;
                    }
                    else {
                        anim_dsc->is_completed = 0;
                    }
                }
                else {
                    if(act_time == (start_time + a->duration)) {
                        if(!anim_dsc->is_completed && a->completed_cb) a->completed_cb(a);
                        anim_dsc->is_completed = 1;
                    }
                    else {
                        anim_dsc->is_completed = 0;
                    }
                }
            }
        }
        else if(act_time > start_time + a->duration) {
            if(anim_timeline_is_started) {
                if(at->reverse) {
                    anim_dsc->is_started = 0;
                }
                else {
                    if(!anim_dsc->is_started && a->start_cb) a->start_cb(a);
                    anim_dsc->is_started = 1;
                }
            }

            value = a->end_value;
            exec_anim(a, value);

            if(anim_timeline_is_started) {
                if(at->reverse) {
                    anim_dsc->is_completed = 0;
                }
                else {
                    if(!anim_dsc->is_completed && a->completed_cb) a->completed_cb(a);
                    anim_dsc->is_completed = 1;
                }
            }
        }
    }
}


static int32_t anim_timeline_path_cb(const lv_anim_t * a)
{
    /*Map the timestamps directly. The default linear path goes through a
     *1024 step intermediate, which quantises `act_time` and would stop a
     *descriptor whose `start_time` falls between two steps from starting.*/
    return lv_map(a->act_time, 0, a->duration, a->start_value, a->end_value);
}

static void anim_timeline_exec_cb(void * var, int32_t v)
{
    lv_anim_timeline_t * at = var;
    anim_timeline_set_act_time(at, v);
}

static void exec_anim(lv_anim_t * a, int32_t v)
{

    if(a->exec_cb) {
        a->exec_cb(a->var, v);
    }
    if(a->custom_exec_cb) {
        a->custom_exec_cb(a, v);
    }
}
