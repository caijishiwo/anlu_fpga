/**
 * @file lv_array.h
 */

#ifndef LV_ARRAY_H
#define LV_ARRAY_H

#ifdef __cplusplus
extern "C" {
#endif

/*********************
 *      INCLUDES
 *********************/
#include "../lvgl_public.h"

/*********************
 *      DEFINES
 *********************/

#ifndef LV_ARRAY_DEFAULT_CAPACITY
#define LV_ARRAY_DEFAULT_CAPACITY  4
#endif

#ifndef LV_ARRAY_DEFAULT_SHRINK_RATIO
#define LV_ARRAY_DEFAULT_SHRINK_RATIO 2
#endif

/**********************
 *      TYPEDEFS
 **********************/

/** Description of a array*/
typedef struct _lv_array_t {
    uint8_t * data;
    uint32_t size;
    uint32_t capacity;
    uint32_t element_size;

    bool inner_alloc; /* true: data is allocated by the array; false: data is allocated by the user */
} lv_array_t;

/**********************
 * GLOBAL PROTOTYPES
 **********************/

/**
 * Init an array.
 * @param array pointer to an `lv_array_t` variable to initialize
 * @param capacity the initial capacity of the array
 * @param element_size the size of an element in bytes
 */
lv_result_t lv_array_init(lv_array_t * array, uint32_t capacity, uint32_t element_size);

/**
 * Init an array from a buffer.
 * @note The buffer must be large enough to store `capacity` elements. The array will not release the buffer and reallocate it.
 *       The user must ensure that the buffer is valid during the lifetime of the array. And release the buffer when the array is no longer needed.
 * @param array pointer to an `lv_array_t` variable to initialize
 * @param buf pointer to a buffer to use as the array's data
 * @param capacity the initial capacity of the array
 * @param element_size the size of an element in bytes
 */
void lv_array_init_from_buf(lv_array_t * array, void * buf, uint32_t capacity, uint32_t element_size);

/**
 * Resize the array to the given capacity.
 * @note if the new capacity is smaller than the current size, the array will be truncated.
 * @param array pointer to an `lv_array_t` variable
 * @param new_capacity the new capacity of the array
 */
bool lv_array_resize(lv_array_t * array, uint32_t new_capacity);

/**
 * Deinit the array, and free the allocated memory
 * @param array pointer to an `lv_array_t` variable to deinitialize
 */
void lv_array_deinit(lv_array_t * array);

/**
 * Return how many elements are stored in the array.
 * @param array pointer to an `lv_array_t` variable
 * @return the number of elements stored in the array
 */
static inline uint32_t lv_array_size(const lv_array_t * array)
{
    return array->size;
}

/**
 * Return the capacity of the array, i.e. how many elements can be stored.
 * @param array pointer to an `lv_array_t` variable
 * @return the capacity of the array
 */
static inline uint32_t lv_array_capacity(const lv_array_t * array)
{
    return array->capacity;
}

/**
 * Return if the array is empty
 * @param array pointer to an `lv_array_t` variable
 * @return true: array is empty; false: array is not empty
 */
static inline bool lv_array_is_empty(const lv_array_t * array)
{
    return array->size == 0;
}

/**
 * Return if the array is full
 * @param array pointer to an `lv_array_t` variable
 * @return true: array is full; false: array is not full
 */
static inline bool lv_array_is_full(const lv_array_t * array)
{
    return array->size == array->capacity;
}

/**
 * Copy an array to another.
 * @note target is always made an exact copy of source. Any existing content in target is
 *       deinitialized. If source is empty, target will also be empty. If target's previous
 *       contents need to be preserved when source is empty, check `lv_array_is_empty` first.
 * @param target pointer to an `lv_array_t` variable to copy to
 * @param source pointer to an `lv_array_t` variable to copy from
 */
void lv_array_copy(lv_array_t * target, const lv_array_t * source);

/**
 * Remove all elements in array.
 * @param array pointer to an `lv_array_t` variable
 */
static inline void lv_array_clear(lv_array_t * array)
{
    array->size = 0;
}

/**
 * Shrink the memory capacity of array if necessary.
 * @param array pointer to an `lv_array_t` variable
 */
void lv_array_shrink(lv_array_t * array);

/**
 * Remove the element at the specified position in the array.
 *
 * This function keeps the array order. Complexity is O(n)
 *
 * @param array pointer to an `lv_array_t` variable
 * @param index the index of the element to remove
 * @return LV_RESULT_OK: success, otherwise: error
 */
lv_result_t lv_array_remove(lv_array_t * array, uint32_t index);

/**
 * Remove the element at the specified position in the array.
 *
 * This function does not guarantee the array order. Complexity is O(1)
 *
 * @param array pointer to an `lv_array_t` variable
 * @param index the index of the element to remove
 * @return LV_RESULT_OK: success, otherwise: error
 */
lv_result_t lv_array_remove_unordered(lv_array_t * array, uint32_t index);

/**
 * Remove from the array either a single element or a range of elements ([start, end)).
 * @note This effectively reduces the container size by the number of elements removed.
 * @note When start equals to end, the function has no effect.
 * @param array pointer to an `lv_array_t` variable
 * @param start the index of the first element to be removed
 * @param end the index of the first element that is not to be removed
 * @return LV_RESULT_OK: success, otherwise: error
 */
lv_result_t lv_array_erase(lv_array_t * array, uint32_t start, uint32_t end);

/**
 * Concatenate two arrays. Adds new elements from `other` to the end of `array`.
 * @note Destination array capacity is automatically expanded as necessary.
 * @note Both arrays must have matching element sizes.
 * @param array pointer to destination `lv_array_t` variable
 * @param other pointer to source `lv_array_t` variable to concatenate
 * @return LV_RESULT_OK: success, LV_RESULT_INVALID: error (NULL pointer, size overflow, element size mismatch)
 */
lv_result_t lv_array_concat(lv_array_t * array, const lv_array_t * other);

/**
 * Push back element. Adds a new element to the end of the array.
 * If the array capacity is not enough for the new element, the array will be resized automatically.
 * @note If the element is NULL, it will be added as an empty element.
 * @param array pointer to an `lv_array_t` variable
 * @param element pointer to the element to add. NULL to push an empty element.
 * @return LV_RESULT_OK: success, otherwise: error
 */
lv_result_t lv_array_push_back(lv_array_t * array, const void * element);

/**
 * Assigns one content to the array, replacing its current content.
 * @param array pointer to an `lv_array_t` variable
 * @param index the index of the element to replace
 * @param value pointer to the elements to add
 * @return LV_RESULT_OK on success or LV_RESULT_INVALID on error
 */
lv_result_t lv_array_assign(lv_array_t * array, uint32_t index, const void * value);

/**
 * Returns a pointer to the element at position n in the array.
 * @param array pointer to an `lv_array_t` variable
 * @param index the index of the element to return
 * @return a pointer to the requested element, NULL if `index` is out of range
 */
void * lv_array_at(const lv_array_t * array, uint32_t index);

/**
 * Returns a pointer to the first element in the array.
 * @param array pointer to an `lv_array_t` variable
 * @return a pointer to the first element in the array
 */
static inline void * lv_array_front(const lv_array_t * array)
{
    return lv_array_at(array, 0);
}

/**
 * Returns a pointer to the last element in the array.
 * @param array pointer to an `lv_array_t` variable
 */
static inline void * lv_array_back(const lv_array_t * array)
{
    return lv_array_at(array, lv_array_size(array) - 1);
}

/**********************
 *      MACROS
 **********************/

#ifdef __cplusplus
} /*extern "C"*/
#endif

#endif
