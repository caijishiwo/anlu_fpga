/**
 * @file lv_button.c
 *
 */

/*********************
 *      INCLUDES
 *********************/

#include "lv_button_private.h"
#include "../../core/lv_obj_class_private.h"

#if LV_USE_BUTTON

/*********************
 *      DEFINES
 *********************/
#define MY_CLASS (&lv_button_class)

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/
static void lv_button_constructor(const lv_obj_class_t * class_p, lv_obj_t * obj);

/**********************
 *  STATIC VARIABLES
 **********************/
const lv_obj_class_t lv_button_class  = {
    .constructor_cb = lv_button_constructor,
    .width_def = LV_SIZE_CONTENT,
    .height_def = LV_SIZE_CONTENT,
    .group_def = LV_OBJ_CLASS_GROUP_DEF_TRUE,
    .instance_size = sizeof(lv_button_t),
    .base_class = &lv_obj_class,
    .name = "lv_button",
};

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

lv_obj_t * lv_button_create(lv_obj_t * parent)
{
    LV_LOG_INFO("begin");
    lv_obj_t * obj = lv_obj_class_create_obj(MY_CLASS, parent);
    lv_obj_class_init_obj(obj);
    return obj;
}

/**********************
 *   STATIC FUNCTIONS
 **********************/

static void lv_button_constructor(const lv_obj_class_t * class_p, lv_obj_t * obj)
{
    LV_UNUSED(class_p);
    LV_TRACE_OBJ_CREATE("begin");

    lv_obj_set_scrollable(obj, false);
    lv_obj_set_scroll_on_focus(obj, true);

    LV_TRACE_OBJ_CREATE("finished");
}

#endif
