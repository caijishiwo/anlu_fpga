/**
 * @file lv_calendar_header_dropdown.c
 *
 */

/*********************
 *      INCLUDES
 *********************/

#include "lv_calendar_private.h"

#if LV_USE_CALENDAR && LV_USE_CALENDAR_HEADER_DROPDOWN

#include "../../core/lv_obj_class_private.h"

/*********************
 *      DEFINES
 *********************/

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/
static void my_constructor(const lv_obj_class_t * class_p, lv_obj_t * obj);
static void year_event_cb(lv_event_t * e);
static void month_event_cb(lv_event_t * e);
static void value_changed_event_cb(lv_event_t * e);

/**********************
 *  STATIC VARIABLES
 **********************/

const lv_obj_class_t lv_calendar_header_dropdown_class = {
    .base_class = &lv_obj_class,
    .width_def = LV_PCT(100),
    .height_def = LV_SIZE_CONTENT,
    .constructor_cb = my_constructor,
    .name = "lv_calendar_header_dropdown",
};

static const char * month_list = "01\n02\n03\n04\n05\n06\n07\n08\n09\n10\n11\n12";
static const char * year_list = {
    "2026\n2025\n2024\n2023\n2022\n2021\n"
    "2020\n2019\n2018\n2017\n2016\n2015\n2014\n2013\n2012\n2011\n2010\n2009\n2008\n2007\n2006\n2005\n2004\n2003\n2002\n2001\n"
    "2000\n1999\n1998\n1997\n1996\n1995\n1994\n1993\n1992\n1991\n1990\n1989\n1988\n1987\n1986\n1985\n1984\n1983\n1982\n1981\n"
    "1980\n1979\n1978\n1977\n1976\n1975\n1974\n1973\n1972\n1971\n1970\n1969\n1968\n1967\n1966\n1965\n1964\n1963\n1962\n1961\n"
    "1960\n1959\n1958\n1957\n1956\n1955\n1954\n1953\n1952\n1951\n1950\n1949\n1948\n1947\n1946\n1945\n1944\n1943\n1942\n1941\n"
    "1940\n1939\n1938\n1937\n1936\n1935\n1934\n1933\n1932\n1931\n1930\n1929\n1928\n1927\n1926\n1925\n1924\n1923\n1922\n1921\n"
    "1920\n1919\n1918\n1917\n1916\n1915\n1914\n1913\n1912\n1911\n1910\n1909\n1908\n1907\n1906\n1905\n1904\n1903\n1902\n1901"
};

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

lv_obj_t * lv_calendar_add_header_dropdown(lv_obj_t * parent)
{
    LV_CHECK_OBJ(parent, &lv_calendar_class, return NULL);

    lv_obj_t * obj = lv_obj_class_create_obj(&lv_calendar_header_dropdown_class, parent);
    lv_obj_class_init_obj(obj);

    return obj;
}

void lv_calendar_header_dropdown_set_year_list(lv_obj_t * parent, const char * years_list)
{
    LV_CHECK_OBJ(parent, &lv_calendar_class, return);
    LV_CHECK_ARG(years_list != NULL, return);

    /* Search for the header dropdown */
    lv_obj_t * header = lv_obj_get_child_by_type(parent, 0, &lv_calendar_header_dropdown_class);
    if(NULL == header) {
        /* Header not found */
        return;
    }

    /* Search for the year dropdown
     * Index is 0 because in the header dropdown constructor the year dropdown (year_dd)
     * is the first created child of the header */
    const int32_t year_dropdown_index = 0;
    lv_obj_t * year_dropdown = lv_obj_get_child_by_type(header, year_dropdown_index, &lv_dropdown_class);
    if(NULL == year_dropdown) {
        /* year dropdown not found */
        return;
    }

    lv_dropdown_clear_options(year_dropdown);
    lv_dropdown_set_options(year_dropdown, years_list);

    lv_obj_invalidate(parent);
}

/**********************
 *  STATIC FUNCTIONS
 **********************/

static void my_constructor(const lv_obj_class_t * class_p, lv_obj_t * obj)
{
    LV_TRACE_OBJ_CREATE("begin");

    LV_UNUSED(class_p);
    LV_ASSERT(obj != NULL);

    lv_obj_t * calendar = lv_obj_get_parent(obj);
    LV_ASSERT(calendar != NULL);
    lv_obj_move_to_index(obj, 0);
    lv_obj_set_flex_flow(obj, LV_FLEX_FLOW_ROW);

    lv_obj_t * year_dd = lv_dropdown_create(obj);
    lv_dropdown_set_options(year_dd, year_list);
    lv_obj_add_event_cb(year_dd, year_event_cb, LV_EVENT_VALUE_CHANGED, calendar);
    lv_obj_set_flex_grow(year_dd, 1);

    lv_obj_t * month_dd = lv_dropdown_create(obj);
    lv_dropdown_set_options(month_dd, month_list);
    lv_obj_add_event_cb(month_dd, month_event_cb, LV_EVENT_VALUE_CHANGED, calendar);
    lv_obj_set_flex_grow(month_dd, 1);

    lv_obj_add_event_cb(obj, value_changed_event_cb, LV_EVENT_VALUE_CHANGED, NULL);

    /*Refresh the drop down*/
    lv_obj_send_event(obj, LV_EVENT_VALUE_CHANGED, NULL);
}

static void month_event_cb(lv_event_t * e)
{
    LV_ASSERT(e != NULL);
    lv_obj_t * dropdown = lv_event_get_current_target(e);
    lv_obj_t * calendar = lv_event_get_user_data(e);
    LV_ASSERT(dropdown != NULL);
    LV_ASSERT(calendar != NULL);

    uint32_t sel = lv_dropdown_get_selected(dropdown);

    const lv_calendar_date_t * d;
    d = lv_calendar_get_showed_date(calendar);
    lv_calendar_date_t newd = *d;
    newd.month = sel + 1;

    lv_calendar_set_month_shown(calendar, newd.year, newd.month);
}

static void year_event_cb(lv_event_t * e)
{
    LV_ASSERT(e != NULL);
    lv_obj_t * dropdown = lv_event_get_current_target(e);
    lv_obj_t * calendar = lv_event_get_user_data(e);
    LV_ASSERT(dropdown != NULL);
    LV_ASSERT(calendar != NULL);

    uint32_t sel = lv_dropdown_get_selected(dropdown);

    const char * year_p = lv_dropdown_get_options(dropdown);

    LV_ASSERT(3 + sel * 5 < lv_strlen(year_p));

    /* NOTE: Assumes YYYY format */
    const uint32_t year = (year_p[0 + sel * 5] - '0') * 1000 +
                          (year_p[1 + sel * 5] - '0') * 100 +
                          (year_p[2 + sel * 5] - '0') * 10 +
                          (year_p[3 + sel * 5] - '0');

    const lv_calendar_date_t * d;
    d = lv_calendar_get_showed_date(calendar);
    lv_calendar_date_t newd = *d;
    newd.year = year;

    lv_calendar_set_month_shown(calendar, newd.year, newd.month);
}

static void value_changed_event_cb(lv_event_t * e)
{
    LV_ASSERT(e != NULL);
    lv_obj_t * header = lv_event_get_current_target(e);
    LV_ASSERT(header != NULL);
    lv_obj_t * calendar = lv_obj_get_parent(header);
    LV_ASSERT(calendar != NULL);
    const lv_calendar_date_t * cur_date = lv_calendar_get_showed_date(calendar);
    lv_obj_t * year_dd = lv_obj_get_child(header, 0);
    lv_obj_t * month_dd = lv_obj_get_child(header, 1);
    const char * year_p = lv_dropdown_get_options(year_dd);
    /* NOTE: Assumes YYYY format */
    const int32_t first_year = (year_p[0] - '0') * 1000 +
                               (year_p[1] - '0') * 100 +
                               (year_p[2] - '0') * 10 + (year_p[3] - '0');
    lv_dropdown_set_selected(year_dd, LV_ABS(first_year - cur_date->year));
    lv_dropdown_set_selected(month_dd, cur_date->month - 1);
}

#endif /*LV_USE_CALENDAR_HEADER_ARROW*/
