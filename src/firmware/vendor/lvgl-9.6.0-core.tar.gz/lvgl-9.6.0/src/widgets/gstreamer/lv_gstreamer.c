/**
 * @file lv_gstreamer.c
 *
 */

/*********************
 *      INCLUDES
 *********************/

#include "lv_gstreamer_private.h"

#include "../../lvgl_public.h"
#if LV_USE_GSTREAMER

#include <glib.h>
#include <gst/gstelementfactory.h>
#include "../../core/lv_obj_class_private.h"
#include "../../misc/lv_event_private.h"

/*********************
 *      DEFINES
 *********************/

#define MY_CLASS (&lv_gstreamer_class)


/**********************
 *      TYPEDEFS
 **********************/

typedef struct {
    const char * factory;
    const char * name;
    GstElement ** store;
} lv_gstreamer_pipeline_element_t;

typedef struct {
    lv_color_format_t color_format;
    const char * gst_format;
} lv_gstreamer_format_t;

/**********************
 *  STATIC PROTOTYPES
 **********************/

static void lv_gstreamer_constructor(const lv_obj_class_t * class_p, lv_obj_t * obj);
static void lv_gstreamer_destructor(const lv_obj_class_t * class_p, lv_obj_t * obj);
static void on_decode_pad_added(GstElement * element, GstPad * pad, gpointer user_data);
static GstFlowReturn on_new_sample(GstElement * sink, gpointer user_data);
static void gstreamer_timer_cb(lv_timer_t * timer);
static lv_result_t gstreamer_poll_bus(lv_gstreamer_t * streamer);
static void gstreamer_update_frame(lv_gstreamer_t * streamer);
static void gstreamer_release_frame(lv_gstreamer_t * streamer);
static bool gstreamer_store_frame(lv_gstreamer_t * streamer, GstSample * sample, GstBuffer * buffer, GstMapInfo * map);
static bool gstreamer_copy_to_aligned_frame(lv_gstreamer_t * streamer, const GstMapInfo * map, uint32_t w, uint32_t h,
                                            uint32_t src_stride);
static lv_result_t gstreamer_make_and_add_to_pipeline(lv_gstreamer_t * streamer,
                                                      const lv_gstreamer_pipeline_element_t * elements, size_t element_count);
static lv_result_t gstreamer_send_state_changed(lv_gstreamer_t * streamer, lv_gstreamer_stream_state_t state);
static bool gstreamer_element_has_property(GstElement * element, const char * property_name);
static const char * gstreamer_get_gst_format(lv_color_format_t color_format);
static lv_color_format_t gstreamer_resolve_color_format(lv_obj_t * obj);
static bool gstreamer_set_child_proxy_string(GstElement * element, const char * property_name, const char * value);

/**********************
 *  STATIC VARIABLES
 **********************/

static const lv_gstreamer_format_t gstreamer_formats[] = {
    {LV_COLOR_FORMAT_RGB565,   "RGB16"},
    {LV_COLOR_FORMAT_RGB888,   "BGR"},
    {LV_COLOR_FORMAT_XRGB8888, "BGRx"},
    {LV_COLOR_FORMAT_ARGB8888, "BGRA"},
};

#define GSTREAMER_FALLBACK_COLOR_FORMAT LV_COLOR_FORMAT_ARGB8888

const lv_obj_class_t lv_gstreamer_class = {
    .constructor_cb = lv_gstreamer_constructor,
    .destructor_cb = lv_gstreamer_destructor,
    .width_def = LV_SIZE_CONTENT,
    .height_def = LV_SIZE_CONTENT,
    .instance_size = sizeof(lv_gstreamer_t),
    .base_class = &lv_image_class,
    .name = "lv_gstreamer",
};

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

lv_obj_t * lv_gstreamer_create(lv_obj_t * parent)
{
    if(!gst_is_initialized()) {
        gst_init(0, NULL);
    }

    LV_TRACE_OBJ_CREATE("begin");

    lv_obj_t * obj = lv_obj_class_create_obj(MY_CLASS, parent);
    lv_obj_class_init_obj(obj);

    LV_TRACE_OBJ_CREATE("end");
    return obj;
}

lv_result_t lv_gstreamer_set_src(lv_obj_t * obj, const char * factory_name, const char * property, const char * source)
{
    LV_CHECK_OBJ(obj, MY_CLASS, return LV_RESULT_INVALID);
    LV_CHECK_ARG(factory_name != NULL, return LV_RESULT_INVALID);

    lv_gstreamer_t * streamer = (lv_gstreamer_t *)obj;

    if(streamer->pipeline) {
        LV_LOG_WARN("LVGL doesn't allow modifying the GStreamer source. Create a new widget with a new src instead");
        return LV_RESULT_INVALID;
    }
    GstElement * pipeline = gst_pipeline_new("lv_gstreamer_pipeline");
    if(!pipeline) {
        LV_LOG_ERROR("Failed to create gstreamer pipeline");
        return LV_RESULT_INVALID;
    }

    GstElement * head = gst_element_factory_make(factory_name, "lv_gstreamer_source");
    if(!head) {
        gst_object_unref(pipeline);
        LV_LOG_ERROR("Failed to create source from factory '%s'", factory_name);
        return LV_RESULT_INVALID;
    }

    if(!gst_bin_add(GST_BIN(pipeline), head)) {
        gst_object_unref(head);
        gst_object_unref(pipeline);
        LV_LOG_ERROR("Failed to add source element to pipeline");
        return LV_RESULT_INVALID;
    }

    if(property != NULL && source != NULL) {
        /* LV_GSTREAMER_PROPERTY_WEBRTCSRC is a child-proxy property path */
        if(lv_streq(property, LV_GSTREAMER_PROPERTY_WEBRTCSRC)) {
            if(!gstreamer_set_child_proxy_string(head, property, source)) {
                gst_object_unref(pipeline);
                LV_LOG_ERROR("Failed to set '%s' via child proxy", property);
                return LV_RESULT_INVALID;
            }
        }
        else {
            g_object_set(G_OBJECT(head), property, source, NULL);
        }
    }

    /* The uri decode source element will automatically handle parsing and decoding for us
     * for other source types, we need to add a parser and a decoder ourselves element*/
    if(!lv_streq(LV_GSTREAMER_FACTORY_URI_DECODE, factory_name)) {
        /* webrtcsrc plugins require its own handling to be able to connect on the first available video stream */
        if(lv_streq(LV_GSTREAMER_FACTORY_WEBRTCSRC, factory_name)) {
            LV_LOG_INFO("Setting up webrtc pipeline");
            if(gstreamer_element_has_property(head, "connect-to-first-producer")) {
                g_object_set(G_OBJECT(head), "connect-to-first-producer", TRUE, NULL);
            }
            else {
                LV_LOG_WARN("webrtcsrc property 'connect-to-first-producer' is not available in this plugin build");
            }
        }
        else {
            GstElement * decodebin = gst_element_factory_make("decodebin", "lv_gstreamer_decodebin");
            if(!decodebin) {
                gst_object_unref(pipeline);
                LV_LOG_ERROR("Failed to create decodebin element");
                return LV_RESULT_INVALID;
            }
            if(!gst_bin_add(GST_BIN(pipeline), decodebin)) {
                gst_object_unref(decodebin);
                gst_object_unref(pipeline);
                LV_LOG_ERROR("Failed to add decodebin element to pipeline");
                return LV_RESULT_INVALID;
            }

            if(!gst_element_link(head, decodebin)) {
                gst_object_unref(pipeline);
                LV_LOG_ERROR("Failed to link source with parsebin elements");
                return LV_RESULT_INVALID;
            }
            head = decodebin;
        }
    }

    /* At this point we don't yet know the input format
     * Once the source starts receiving the data, it will create the necessary pads,
     * i.e one pad for audio and one for video
     * We add a callback so that we automatically connect to the data once it's figured out*/
    g_signal_connect(head, "pad-added", G_CALLBACK(on_decode_pad_added), streamer);

    streamer->color_format = gstreamer_resolve_color_format(obj);

    streamer->pipeline = pipeline;
    return LV_RESULT_OK;
}

void lv_gstreamer_play(lv_obj_t * obj)
{
    LV_CHECK_OBJ(obj, MY_CLASS, return);
    if(!obj) {
        return;
    }
    lv_gstreamer_t * streamer = (lv_gstreamer_t *)obj;
    if(!streamer->pipeline) {
        LV_LOG_WARN("Cannot play: GStreamer pipeline not initialized");
        return;
    }
    GstStateChangeReturn ret = gst_element_set_state(streamer->pipeline, GST_STATE_PLAYING);
    if(ret == GST_STATE_CHANGE_FAILURE) {
        LV_LOG_ERROR("Unable to play pipeline");
        return;
    }
    gstreamer_send_state_changed(streamer, LV_GSTREAMER_STREAM_STATE_PLAY);
}

void lv_gstreamer_pause(lv_obj_t * obj)
{
    LV_CHECK_OBJ(obj, MY_CLASS, return);
    if(!obj) {
        return;
    }
    lv_gstreamer_t * streamer = (lv_gstreamer_t *)obj;
    if(!streamer->pipeline) {
        LV_LOG_WARN("Cannot pause: GStreamer pipeline not initialized");
        return;
    }
    GstStateChangeReturn ret = gst_element_set_state(streamer->pipeline, GST_STATE_PAUSED);

    if(ret == GST_STATE_CHANGE_FAILURE) {
        LV_LOG_ERROR("Unable to pause pipeline");
        return;
    }
    gstreamer_send_state_changed(streamer, LV_GSTREAMER_STREAM_STATE_PAUSE);
}

void lv_gstreamer_stop(lv_obj_t * obj)
{
    LV_CHECK_OBJ(obj, MY_CLASS, return);
    if(!obj) {
        return;
    }
    lv_gstreamer_t * streamer = (lv_gstreamer_t *)obj;
    if(!streamer->pipeline) {
        LV_LOG_WARN("Cannot stop: GStreamer pipeline not initialized");
        return;
    }
    GstStateChangeReturn ret = gst_element_set_state(streamer->pipeline, GST_STATE_READY);
    if(ret == GST_STATE_CHANGE_FAILURE) {
        LV_LOG_ERROR("Unable to stop pipeline");
        return;
    }
    gstreamer_send_state_changed(streamer, LV_GSTREAMER_STREAM_STATE_STOP);
}
void lv_gstreamer_set_position(lv_obj_t * obj, uint32_t position)
{
    LV_CHECK_OBJ(obj, MY_CLASS, return);
    if(!obj) {
        return;
    }
    lv_gstreamer_t * streamer = (lv_gstreamer_t *)obj;
    if(!streamer->pipeline) {
        LV_LOG_WARN("Cannot set position: GStreamer pipeline not initialized");
        return;
    }
    gint64 seek_position = (gint64)position * GST_MSECOND;

    if(!gst_element_seek_simple(streamer->pipeline, GST_FORMAT_TIME,
                                GST_SEEK_FLAG_FLUSH | GST_SEEK_FLAG_KEY_UNIT,
                                seek_position)) {
        LV_LOG_WARN("Seek operation failed");
    }
}

uint32_t lv_gstreamer_get_duration(lv_obj_t * obj)
{
    LV_CHECK_OBJ(obj, MY_CLASS, return 0);
    lv_gstreamer_t * streamer = (lv_gstreamer_t *)obj;

    if(!streamer->pipeline) {
        return 0;
    }

    gint64 duration;
    if(gst_element_query_duration(streamer->pipeline, GST_FORMAT_TIME, &duration)) {
        return (uint32_t)(duration / GST_MSECOND);
    }

    return 0;
}

uint32_t lv_gstreamer_get_position(lv_obj_t * obj)
{
    LV_CHECK_OBJ(obj, MY_CLASS, return 0);
    lv_gstreamer_t * streamer = (lv_gstreamer_t *)obj;

    if(!streamer->pipeline) {
        return 0;
    }

    gint64 position;
    if(gst_element_query_position(streamer->pipeline, GST_FORMAT_TIME, &position)) {
        return (uint32_t)(position / GST_MSECOND);
    }

    return 0;
}

lv_gstreamer_state_t lv_gstreamer_get_state(lv_obj_t * obj)
{
    LV_CHECK_OBJ(obj, MY_CLASS, return LV_GSTREAMER_STATE_NULL);
    lv_gstreamer_t * streamer = (lv_gstreamer_t *)obj;

    if(!streamer->pipeline) {
        return LV_GSTREAMER_STATE_NULL;
    }

    GstState state, pending;
    GstStateChangeReturn ret = gst_element_get_state(streamer->pipeline, &state, &pending, 0);

    if(ret == GST_STATE_CHANGE_FAILURE) {
        return LV_GSTREAMER_STATE_NULL;
    }

    switch(state) {
        case GST_STATE_NULL:
            return LV_GSTREAMER_STATE_NULL;
        case GST_STATE_READY:
            return LV_GSTREAMER_STATE_READY;
        case GST_STATE_PAUSED:
            return LV_GSTREAMER_STATE_PAUSED;
        case GST_STATE_PLAYING:
            return LV_GSTREAMER_STATE_PLAYING;
        default:
            return LV_GSTREAMER_STATE_NULL;
    }
}

void lv_gstreamer_set_volume(lv_obj_t * obj, uint8_t volume)
{

    LV_CHECK_OBJ(obj, MY_CLASS, return);
    lv_gstreamer_t * streamer = (lv_gstreamer_t *)obj;

    if(!streamer->audio_volume) {
        return;
    }

    g_object_set(streamer->audio_volume, "volume", volume / 100.f, NULL);
}

uint8_t lv_gstreamer_get_volume(lv_obj_t * obj)
{
    LV_CHECK_OBJ(obj, MY_CLASS, return 0);
    lv_gstreamer_t * streamer = (lv_gstreamer_t *)obj;

    if(!streamer->audio_volume) {
        return 0;
    }

    gdouble volume;
    g_object_get(streamer->audio_volume, "volume",  &volume, NULL);

    return (uint8_t)(volume * 100.f);
}

void lv_gstreamer_set_rate(lv_obj_t * obj, uint32_t rate)
{

    LV_CHECK_OBJ(obj, MY_CLASS, return);
    lv_gstreamer_t * streamer = (lv_gstreamer_t *)obj;

    if(!streamer->pipeline) {
        return;
    }

    gdouble gst_rate = (gdouble)rate / 256.0;

    gint64 current_pos;

    if(!gst_element_query_position(streamer->pipeline, GST_FORMAT_TIME, &current_pos)) {
        LV_LOG_WARN("Failed to query current position which is required to set the stream rate");
        return;
    }

    /* Perform the seek with new rate from the current position */
    if(!gst_element_seek(streamer->pipeline, gst_rate,
                         GST_FORMAT_TIME,
                         GST_SEEK_FLAG_FLUSH | GST_SEEK_FLAG_ACCURATE,
                         GST_SEEK_TYPE_SET, current_pos,
                         GST_SEEK_TYPE_NONE, GST_CLOCK_TIME_NONE)) {
        LV_LOG_WARN("Failed to change stream rate");
    }
}

lv_gstreamer_stream_state_t lv_gstreamer_get_stream_state(lv_event_t * e)
{
    LV_CHECK_ARG(e != NULL, return LV_GSTREAMER_STREAM_STATE_INVALID);
    LV_CHECK_ARG(e->code == LV_EVENT_STATE_CHANGED, return LV_GSTREAMER_STREAM_STATE_INVALID);
    return *(lv_gstreamer_stream_state_t *)lv_event_get_param(e);
}

/**********************
 *   STATIC FUNCTIONS
 **********************/

static void lv_gstreamer_constructor(const lv_obj_class_t * class_p, lv_obj_t * obj)
{
    LV_ASSERT(obj != NULL);
    LV_UNUSED(class_p);
    LV_TRACE_OBJ_CREATE("begin");
    lv_gstreamer_t * streamer = (lv_gstreamer_t *)obj;
    lv_memzero(&streamer->frame, sizeof(streamer->frame));
    streamer->color_format = GSTREAMER_FALLBACK_COLOR_FORMAT;

    streamer->gstreamer_timer = lv_timer_create(gstreamer_timer_cb, LV_DEF_REFR_PERIOD / 5, streamer);
    LV_ASSERT(streamer->gstreamer_timer != NULL);

    streamer->frame_queue = g_async_queue_new();
    LV_ASSERT(streamer->frame_queue != NULL);
    streamer->last_sample = NULL;

    LV_TRACE_OBJ_CREATE("finished");
}

static lv_result_t gstreamer_poll_bus(lv_gstreamer_t * streamer)
{
    LV_ASSERT(streamer != NULL);
    GstBus * bus = gst_element_get_bus(streamer->pipeline);
    GstMessage * msg;

    while((msg = gst_bus_pop(bus)) != NULL) {
        const GstMessageType message_type = GST_MESSAGE_TYPE(msg);
        switch(message_type) {
            case GST_MESSAGE_ERROR: {
                    GError * err;
                    gchar * debug;
                    gst_message_parse_error(msg, &err, &debug);
                    GstObject * src = GST_MESSAGE_SRC(msg);
                    const gchar * name = NULL;
                    if(src != NULL) {
                        name = GST_OBJECT_NAME(src);
                    }
                    if(!name) {
                        name = "unknown";
                    }
                    LV_LOG_ERROR("GStreamer error from %s: %s", name, err->message);
                    if(debug && debug[0] != '\0') {
                        LV_LOG_ERROR("GStreamer error details: %s", debug);
                    }
                    g_error_free(err);
                    g_free(debug);
                    break;
                }
            case GST_MESSAGE_EOS:
                if(gstreamer_send_state_changed(streamer, LV_GSTREAMER_STREAM_STATE_END) == LV_RESULT_INVALID) {
                    /* Object deleted inside event handler */
                    gst_object_unref(bus);
                    gst_message_unref(msg);
                    return LV_RESULT_INVALID;
                }
                break;
            case GST_MESSAGE_STATE_CHANGED: {
                    GstState old_state, new_state;
                    gst_message_parse_state_changed(msg, &old_state, &new_state, NULL);
                    LV_LOG_INFO("State changed: %s -> %s", gst_element_state_get_name(old_state),
                                gst_element_state_get_name(new_state));
                    break;
                }
            default:
                LV_LOG_TRACE("Received message %d", message_type);
                break;
        }
        gst_message_unref(msg);
    }
    gst_object_unref(bus);
    return LV_RESULT_OK;
}

static void gstreamer_update_frame(lv_gstreamer_t * streamer)
{
    LV_ASSERT(streamer != NULL);
    GstSample * sample = g_async_queue_try_pop(streamer->frame_queue);

    if(!sample) {
        return;
    }

    const bool first_frame = !streamer->is_video_info_valid;
    if(first_frame) {
        GstCaps * caps = gst_sample_get_caps(sample);
        if(!caps || !gst_video_info_from_caps(&streamer->video_info, caps)) {
            LV_LOG_ERROR("Failed to get video info from caps");
            gst_sample_unref(sample);
            return;
        }
        streamer->is_video_info_valid = true;
    }


    GstBuffer * buffer = gst_sample_get_buffer(sample);
    GstMapInfo map;
    if(!buffer || !gst_buffer_map(buffer, &map, GST_MAP_READ)) {
        gst_sample_unref(sample);
    }
    bool stored = gstreamer_store_frame(streamer, sample, buffer, &map);
    if(first_frame && !stored) {
        streamer->is_video_info_valid = false;
        return;
    }
    lv_image_set_src((lv_obj_t *)streamer, &streamer->frame);

    /* We send the event AFTER setting the image source so that users can query the
     * resolution on this specific event callback */
    if(first_frame) {
        if(gstreamer_send_state_changed(streamer, LV_GSTREAMER_STREAM_STATE_START) == LV_RESULT_INVALID) {
            /* Object deleted inside event handler */
            return;
        }
        /*Send READY event for backwards compatibility with v9.4*/
        lv_obj_send_event((lv_obj_t *)streamer, LV_EVENT_READY, streamer);
    }

}

static bool gstreamer_store_frame(lv_gstreamer_t * streamer, GstSample * sample, GstBuffer * buffer, GstMapInfo * map)
{
    const uint32_t w = GST_VIDEO_INFO_WIDTH(&streamer->video_info);
    const uint32_t h = GST_VIDEO_INFO_HEIGHT(&streamer->video_info);
    const uint32_t src_stride = GST_VIDEO_INFO_PLANE_STRIDE(&streamer->video_info, 0);

    const bool aligned = (lv_uintptr_t)map->data % LV_DRAW_BUF_ALIGN == 0
                         && src_stride == lv_draw_buf_width_to_stride(w, streamer->color_format);

    gstreamer_release_frame(streamer);

    if(aligned) {
        streamer->last_buffer = buffer;
        streamer->last_map_info = *map;
        streamer->last_sample = sample;
    }
    else {
        const bool copied = gstreamer_copy_to_aligned_frame(streamer, map, w, h, src_stride);
        gst_buffer_unmap(buffer, map);
        gst_sample_unref(sample);
        if(!copied) {
            return false;
        }
    }

    const lv_draw_buf_t * copy = streamer->aligned_frame;
    streamer->frame = (lv_image_dsc_t) {
        .data = aligned ? map->data : copy->data,
        .data_size = aligned ? map->size : copy->data_size,
        .header = {
            .magic = LV_IMAGE_HEADER_MAGIC,
            .cf = streamer->color_format,
            .flags = LV_IMAGE_FLAGS_MODIFIABLE,
            .h = h,
            .w = w,
            .stride = aligned ? src_stride : copy->header.stride,
        }
    };
    return true;
}

static bool gstreamer_copy_to_aligned_frame(lv_gstreamer_t * streamer, const GstMapInfo * map, uint32_t w, uint32_t h,
                                            uint32_t src_stride)
{
    lv_draw_buf_t * dest = streamer->aligned_frame;
    if(dest && (dest->header.w != w || dest->header.h != h)) {
        lv_draw_buf_destroy(dest);
        dest = NULL;
        streamer->aligned_frame = NULL;
    }

    if(!dest) {
        dest = lv_draw_buf_create(w, h, streamer->color_format, LV_STRIDE_AUTO);
        if(!dest) {
            LV_LOG_ERROR("Failed to allocate an aligned %" LV_PRIu32 "x%" LV_PRIu32 " frame", w, h);
            return false;
        }
        streamer->aligned_frame = dest;
    }

    const uint32_t dest_stride = dest->header.stride;
    const uint32_t row_size = LV_MIN(src_stride, dest_stride);
    for(uint32_t y = 0; y < h; y++) {
        lv_memcpy(dest->data + y * dest_stride, map->data + y * src_stride, row_size);
    }

    lv_draw_buf_flush_cache(dest, NULL);
    return true;
}

static void gstreamer_release_frame(lv_gstreamer_t * streamer)
{
    if(streamer->last_buffer) {
        gst_buffer_unmap(streamer->last_buffer, &streamer->last_map_info);
        streamer->last_buffer = NULL;
    }
    if(streamer->last_sample) {
        gst_sample_unref(streamer->last_sample);
        streamer->last_sample = NULL;
    }
}

static void gstreamer_timer_cb(lv_timer_t * timer)
{
    LV_ASSERT(timer != NULL);
    lv_gstreamer_t * streamer = lv_timer_get_user_data(timer);

    if(!streamer->pipeline) {
        return;
    }

    if(gstreamer_poll_bus(streamer) == LV_RESULT_INVALID) {
        return;
    }
    gstreamer_update_frame(streamer);
}

static void lv_gstreamer_destructor(const lv_obj_class_t * class_p, lv_obj_t * obj)
{
    LV_ASSERT(obj != NULL);
    LV_UNUSED(class_p);
    lv_gstreamer_t * streamer = (lv_gstreamer_t *)obj;

    if(streamer->pipeline) {
        gst_element_set_state(streamer->pipeline, GST_STATE_NULL);
        gst_object_unref(streamer->pipeline);
    }
    gstreamer_release_frame(streamer);
    if(streamer->aligned_frame) {
        lv_draw_buf_destroy(streamer->aligned_frame);
    }
    if(streamer->frame_queue) {
        GstSample * sample;
        while((sample = g_async_queue_try_pop(streamer->frame_queue)) != NULL) {
            gst_sample_unref(sample);
        }
        g_async_queue_unref(streamer->frame_queue);
        streamer->frame_queue = NULL;
    }
    lv_timer_delete(streamer->gstreamer_timer);
}

static lv_result_t gstreamer_make_and_add_to_pipeline(lv_gstreamer_t * streamer,
                                                      const lv_gstreamer_pipeline_element_t * elements, size_t element_count)
{
    for(size_t i = 0; i < element_count; ++i) {
        GstElement * el = gst_element_factory_make(elements[i].factory, elements[i].name);
        if(!el) {
            /* The previous elements were added to the pipeline so we don't need to unref them explicitly
             * Unrefing the pipeline is enough and is done by caller*/
            LV_LOG_ERROR("Failed to create %s element", elements[i].name);
            return LV_RESULT_INVALID;
        }
        *(elements[i].store) = el;
        if(!gst_bin_add(GST_BIN(streamer->pipeline), el)) {
            gst_object_unref(el);
            LV_LOG_ERROR("Failed to add %s element to pipeline", elements[i].name);
            return LV_RESULT_INVALID;
        }
    }
    return LV_RESULT_OK;
}

static const char * gstreamer_get_gst_format(lv_color_format_t color_format)
{
    for(size_t i = 0; i < sizeof(gstreamer_formats) / sizeof(gstreamer_formats[0]); ++i) {
        if(gstreamer_formats[i].color_format == color_format) {
            return gstreamer_formats[i].gst_format;
        }
    }
    return NULL;
}

static lv_color_format_t gstreamer_resolve_color_format(lv_obj_t * obj)
{
    LV_ASSERT(obj != NULL);
    lv_display_t * display = lv_obj_get_display(obj);
    if(!display) {
        LV_LOG_WARN("Widget is on no display, decoding to the fallback color format");
        return GSTREAMER_FALLBACK_COLOR_FORMAT;
    }

    const lv_color_format_t color_format = lv_display_get_color_format(display);
    if(!gstreamer_get_gst_format(color_format)) {
        LV_LOG_INFO("No GStreamer equivalent for color format %d, decoding to the fallback one", (int)color_format);
        return GSTREAMER_FALLBACK_COLOR_FORMAT;
    }

    return color_format;
}

static bool gstreamer_element_has_property(GstElement * element, const char * property_name)
{
    LV_ASSERT(element != NULL);
    LV_ASSERT(property_name != NULL);

    GObjectClass * klass = G_OBJECT_GET_CLASS(element);
    return g_object_class_find_property(klass, property_name) != NULL;
}

static bool gstreamer_set_child_proxy_string(GstElement * element, const char * property_name, const char * value)
{
    LV_ASSERT(element != NULL);
    LV_ASSERT(property_name != NULL);
    LV_ASSERT(value != NULL);

    if(!GST_IS_CHILD_PROXY(element)) {
        LV_LOG_WARN("Element does not support child proxy for property '%s'", property_name);
        return false;
    }

    GObject * target = NULL;
    GParamSpec * pspec = NULL;
    if(!gst_child_proxy_lookup(GST_CHILD_PROXY(element), property_name, &target, &pspec)) {
        LV_LOG_WARN("Property '%s' not found in child proxy", property_name);
        return false;
    }

    if(target) {
        g_object_unref(target);
    }

    GValue gvalue = G_VALUE_INIT;
    g_value_init(&gvalue, G_TYPE_STRING);
    g_value_set_string(&gvalue, value);
    gst_child_proxy_set_property(GST_CHILD_PROXY(element), property_name, &gvalue);
    g_value_unset(&gvalue);
    return true;
}

static void on_decode_pad_added(GstElement * element, GstPad * pad, gpointer user_data)
{
    LV_ASSERT(element != NULL);
    LV_ASSERT(pad != NULL);
    LV_UNUSED(element);
    lv_gstreamer_t * streamer = (lv_gstreamer_t *)user_data;
    GstCaps * caps = gst_pad_query_caps(pad, NULL);

    GstStructure * structure = gst_caps_get_structure(caps, 0);
    const gchar * name = gst_structure_get_name(structure);

    LV_LOG_TRACE("Pad discovered %s", name);

    if(g_str_has_prefix(name, "video/")) {
        if(!streamer->video_convert) {
            GstElement * video_app_sink;
            GstElement * video_rate;
            GstElement * video_queue;
            const lv_gstreamer_pipeline_element_t elements[] = {
                {"videoconvert",  "lv_gstreamer_video_convert",  &streamer->video_convert},
                {"videorate",     "lv_gstreamer_video_rate",     &video_rate},
                {"queue",         "lv_gstreamer_video_queue",    &video_queue},
                {"appsink",       "lv_gstreamer_video_sink",     &video_app_sink},
            };
            const size_t element_count = sizeof(elements) / sizeof(elements[0]);
            if(gstreamer_make_and_add_to_pipeline(streamer, elements, element_count) != LV_RESULT_OK) {
                goto exit;
            }

            /* Here we set the fps we want the pipeline to produce and the color format
             * This is achieved by the video_convert and video_rate elements that will automatically throttle and
             * convert the image to the format we desire*/
            uint32_t target_fps = 1000 / LV_DEF_REFR_PERIOD;
            char caps_str[128];
            lv_snprintf(caps_str, sizeof(caps_str), "video/x-raw,format=%s,framerate=%" LV_PRIu32 "/1",
                        gstreamer_get_gst_format(streamer->color_format), target_fps);

            GstCaps * appsink_caps = gst_caps_from_string(caps_str);
            g_object_set(G_OBJECT(video_app_sink), "emit-signals", TRUE, "sync", TRUE, "max-buffers", 1, "drop", TRUE, "caps",
                         appsink_caps, NULL);
            gst_caps_unref(appsink_caps);

            if(!gst_element_link_many(streamer->video_convert, video_rate, video_queue, video_app_sink, NULL)) {
                LV_LOG_ERROR("Failed to link video convert to sink");
                goto exit;
            }
            for(size_t i = 0; i < element_count; ++i) {
                gst_element_sync_state_with_parent(*elements[i].store);
            }
            g_signal_connect(video_app_sink, "new-sample", G_CALLBACK(on_new_sample), streamer);
        }

        GstPad * video_convert_sink_pad = gst_element_get_static_pad(streamer->video_convert, "sink");
        if(gst_pad_is_linked(video_convert_sink_pad)) {
            LV_LOG_WARN("Received another video pad '%s' but our video pipeline is already linked - Ignoring", name);
        }
        else if(gst_pad_link(pad, video_convert_sink_pad) != GST_PAD_LINK_OK) {
            LV_LOG_ERROR("Failed to link discovered pad '%s' to videoconvert", name);
        }
        gst_object_unref(video_convert_sink_pad);
    }
    else if(g_str_has_prefix(name, "audio/")) {
        if(!streamer->audio_convert) {
            GstElement * audio_resample;
            GstElement * audio_sink;
            const lv_gstreamer_pipeline_element_t elements[] = {
                {"audioconvert",  "lv_gstreamer_audio_convert",  &streamer->audio_convert},
                {"volume",        "lv_gstreamer_audio_volume",   &streamer->audio_volume},
                {"audioresample", "lv_gstreamer_audio_resample", &audio_resample},
                {"autoaudiosink", "lv_gstreamer_audio_sink",     &audio_sink},
            };
            const size_t element_count = sizeof(elements) / sizeof(elements[0]);
            if(gstreamer_make_and_add_to_pipeline(streamer, elements, element_count) != LV_RESULT_OK) {
                goto exit;
            }
            if(!gst_element_link_many(streamer->audio_convert, audio_resample, streamer->audio_volume, audio_sink, NULL)) {
                LV_LOG_ERROR("Failed to link audio convert to sink");
                goto exit;
            }
            for(size_t i = 0; i < element_count; ++i) {
                gst_element_sync_state_with_parent(*elements[i].store);
            }
        }

        GstPad * audio_convert_sink_pad = gst_element_get_static_pad(streamer->audio_convert, "sink");
        if(!gst_pad_is_linked(audio_convert_sink_pad)) {
            if(gst_pad_link(pad, audio_convert_sink_pad) != GST_PAD_LINK_OK) {
                LV_LOG_ERROR("Failed to link discovered pad '%s' to audioconvert", name);
            }
        }
        else {
            LV_LOG_WARN("Received another audio pad  '%s' but our audio pipeline is already linked - Ignoring", name);
        }
        gst_object_unref(audio_convert_sink_pad);
    }

exit:
    gst_caps_unref(caps);
}

static GstFlowReturn on_new_sample(GstElement * sink, gpointer user_data)
{
    LV_ASSERT(sink != NULL);
    /* This function is called from a thread other than the main one so we can't call anything related to LVGL here
     * Instead, we acquire the new sample (the new frame) and push it to the queue so that we can retrieve it from an LVGL timer
     * Note that the pipeline spits out a new frame every LV_DEF_REFR_PERIOD as per the way it's set up so we shouldn't ever lose any
     * frames with this method*/
    lv_gstreamer_t * streamer = (lv_gstreamer_t *)user_data;
    GstSample * sample;

    g_signal_emit_by_name(sink, "pull-sample", &sample);
    if(!sample) {
        return GST_FLOW_OK;
    }

    g_async_queue_lock(streamer->frame_queue);
    g_async_queue_push_unlocked(streamer->frame_queue, sample);
    while(g_async_queue_length_unlocked(streamer->frame_queue) > LV_GSTREAMER_MAX_QUEUED_FRAMES) {
        GstSample * dropped = g_async_queue_try_pop_unlocked(streamer->frame_queue);
        if(!dropped) {
            break;
        }
        gst_sample_unref(dropped);
    }
    g_async_queue_unlock(streamer->frame_queue);

    return GST_FLOW_OK;
}

static lv_result_t gstreamer_send_state_changed(lv_gstreamer_t * streamer, lv_gstreamer_stream_state_t state)
{
    LV_ASSERT(streamer != NULL);
    return lv_obj_send_event((lv_obj_t *)streamer, LV_EVENT_STATE_CHANGED, &state);
}
#endif
