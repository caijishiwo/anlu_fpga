/**
 * @file lv_list.c
 *
 */

/*********************
 *      INCLUDES
 *********************/


#include "../../lvgl_public.h"

#if LV_USE_LIST

#include "../../core/lv_obj_class_private.h"

/*The `lv_list` API is deprecated as a whole and its functions call each other.*/
LV_DEPRECATIONS_IGNORE_BEGIN

/*********************
 *      DEFINES
 *********************/
#define MY_CLASS        (&lv_list_class)
#define MY_CLASS_BUTTON (&lv_list_button_class)
#define MY_CLASS_TEXT   (&lv_list_text_class)

/**********************
 *      TYPEDEFS
 **********************/

/**********************
 *  STATIC PROTOTYPES
 **********************/
const lv_obj_class_t lv_list_class = {
    .base_class = &lv_obj_class,
    .width_def = (LV_DPI_DEF * 3) / 2,
    .height_def = LV_DPI_DEF * 2,
    .name = "lv_list",
};

const lv_obj_class_t lv_list_button_class = {
    .base_class = &lv_button_class,
    .width_def = LV_PCT(100),
    .height_def = LV_SIZE_CONTENT,
    .name = "lv_list_button",
};

const lv_obj_class_t lv_list_text_class = {
    .base_class = &lv_label_class,
    .width_def = LV_PCT(100),
    .height_def = LV_SIZE_CONTENT,
    .name = "lv_list_text",
};

/**********************
 *  STATIC VARIABLES
 **********************/

/**********************
 *      MACROS
 **********************/

/**********************
 *   GLOBAL FUNCTIONS
 **********************/

lv_obj_t * lv_list_create(lv_obj_t * parent)
{
    LV_LOG_DEPRECATED(LV_LIST_DEPRECATED_MSG);
    LV_LOG_INFO("begin");
    lv_obj_t * obj = lv_obj_class_create_obj(MY_CLASS, parent);
    lv_obj_class_init_obj(obj);
    lv_obj_set_flex_flow(obj, LV_FLEX_FLOW_COLUMN);
    return obj;
}

lv_obj_t * lv_list_add_text(lv_obj_t * list, const char * txt)
{
    LV_CHECK_OBJ(list, MY_CLASS, return NULL);

    LV_LOG_DEPRECATED(LV_LIST_DEPRECATED_MSG);
    LV_LOG_INFO("begin");

    lv_obj_t * obj = lv_obj_class_create_obj(MY_CLASS_TEXT, list);
    lv_obj_class_init_obj(obj);
    lv_label_set_text(obj, txt);
    return obj;
}

lv_obj_t * lv_list_add_button(lv_obj_t * list, const void * icon, const char * txt)
{
    LV_CHECK_OBJ(list, MY_CLASS, return NULL);

    LV_LOG_DEPRECATED(LV_LIST_DEPRECATED_MSG);
    LV_LOG_INFO("begin");
    lv_obj_t * obj = lv_obj_class_create_obj(MY_CLASS_BUTTON, list);
    lv_obj_class_init_obj(obj);
    lv_obj_set_flex_flow(obj, LV_FLEX_FLOW_ROW);

#if LV_USE_IMAGE == 1
    if(icon) {
        lv_obj_t * img = lv_image_create(obj);
        lv_image_set_src(img, icon);
    }
#endif

    if(txt) {
        lv_obj_t * label = lv_label_create(obj);
        lv_label_set_text(label, txt);
        lv_label_set_long_mode(label, LV_LABEL_LONG_MODE_SCROLL_CIRCULAR);
        lv_obj_set_flex_grow(label, 1);
    }

    return obj;
}

const char * lv_list_get_button_text(lv_obj_t * list, lv_obj_t * btn)
{
    LV_CHECK_OBJ(list, MY_CLASS, return NULL);
    LV_CHECK_ARG(btn != NULL, return NULL);

    LV_LOG_DEPRECATED(LV_LIST_DEPRECATED_MSG);
    LV_UNUSED(list);
    uint32_t i;
    for(i = 0; i < lv_obj_get_child_count(btn); i++) {
        lv_obj_t * child = lv_obj_get_child(btn, i);
        if(lv_obj_check_type(child, &lv_label_class)) {
            return lv_label_get_text(child);
        }

    }

    return "";
}

void lv_list_set_button_text(lv_obj_t * list, lv_obj_t * btn, const char * txt)
{
    LV_CHECK_OBJ(list, MY_CLASS, return);
    LV_CHECK_ARG(btn != NULL, return);
    LV_CHECK_ARG(txt != NULL, return);

    LV_LOG_DEPRECATED(LV_LIST_DEPRECATED_MSG);
    LV_UNUSED(list);
    uint32_t i;
    for(i = 0; i < lv_obj_get_child_count(btn); i++) {
        lv_obj_t * child = lv_obj_get_child(btn, i);
        if(lv_obj_check_type(child, &lv_label_class)) {
            lv_label_set_text(child, txt);
            return;
        }
    }
}

#if LV_USE_TRANSLATION

lv_obj_t * lv_list_add_translation_tag(lv_obj_t * list, const char * tag)
{
    LV_CHECK_OBJ(list, MY_CLASS, return NULL);
    LV_CHECK_ARG(tag != NULL, return NULL);

    LV_LOG_DEPRECATED(LV_LIST_DEPRECATED_MSG);
    LV_LOG_INFO("begin");

    lv_obj_t * obj = lv_list_add_text(list, NULL);
    lv_label_set_translation_tag(obj, tag);
    return obj;
}

lv_obj_t * lv_list_add_button_translation_tag(lv_obj_t * list, const void * icon, const char * tag)
{
    LV_CHECK_OBJ(list, MY_CLASS, return NULL);

    LV_LOG_DEPRECATED(LV_LIST_DEPRECATED_MSG);
    LV_LOG_INFO("begin");

    lv_obj_t * obj = lv_list_add_button(list, icon, "");
    if(tag != NULL) lv_list_set_button_translation_tag(list, obj, tag);

    return obj;
}

void lv_list_set_button_translation_tag(lv_obj_t * list, lv_obj_t * btn, const char * tag)
{
    LV_CHECK_OBJ(list, MY_CLASS, return);
    LV_CHECK_ARG(btn != NULL, return);
    LV_CHECK_ARG(tag != NULL, return);

    LV_LOG_DEPRECATED(LV_LIST_DEPRECATED_MSG);
    LV_UNUSED(list);
    uint32_t i;
    for(i = 0; i < lv_obj_get_child_count(btn); i++) {
        lv_obj_t * child = lv_obj_get_child(btn, i);
        if(lv_obj_check_type(child, &lv_label_class)) {
            lv_label_set_translation_tag(child, tag);
            return;
        }
    }
}

#endif

/**********************
 *   STATIC FUNCTIONS
 **********************/

LV_DEPRECATIONS_IGNORE_END

#endif /*LV_USE_LIST*/
